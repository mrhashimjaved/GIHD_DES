// ============================================================
//  DATA ENTRY SYSTEM — Google Apps Script
//  Paste this entire file into:
//  Google Sheets → Extensions → Apps Script → Code.gs
//
//  Then: Deploy → New Deployment → Web App
//        Execute as: Me
//        Who has access: Anyone
//  Copy the Web App URL into form.html → GOOGLE_SHEETS_URL
// ============================================================


// ── CONFIGURATION ────────────────────────────────────────────

// Fields used to detect duplicate records (must match form.html IDENTIFIER_FIELDS)
const DUPLICATE_KEY_FIELDS = [
  'School_ID',
  'Child_Name',
  'Father_Name',
  'Child_Roll_num',
  'Class_Section'
];

// Columns that will always appear first in every sheet, before data fields
const META_COLUMNS = ['timestamp', 'deo', 'stream'];

// Fields to exclude from data columns (already in META_COLUMNS or internal)
const EXCLUDED_FROM_DATA = ['timestamp', 'deo', 'stream', 'overwrite'];

// Exact column order for every sheet.
// This guarantees SPSS-ready output in the correct variable order
// regardless of submission order.
// If a new tool is added to the form, add its variable names here too.
const COLUMN_ORDER = [
  // ── META ──────────────────────────────────────────────────
  'timestamp',
  'deo',
  'stream',

  // ── SECTION A: Record Identifiers ─────────────────────────
  'Serial_No',
  'School_ID',
  'School_Name',
  'Child_Name',
  'Father_Name',
  'Class_Section',
  'Child_Roll_num',

  // ── SECTION B: Child Demographics ─────────────────────────
  'Child_age',
  'Child_gender',
  'Number_of_siblings',

  // ── SECTION C: Father ──────────────────────────────────────
  'Father_Alive',
  'Father_working',
  'Father_occupation',
  'Father_Education',

  // ── SECTION D: Mother ──────────────────────────────────────
  'Mother_Alive',
  'Mother_working',
  'Mother_occupation',
  'Mother_Education',

  // ── SECTION E: Contact ─────────────────────────────────────
  'Contact_no',
  'Address',

  // ── SECTION F: MMAPP Items 1–25 ───────────────────────────
  'MMAPP_item_01','MMAPP_item_02','MMAPP_item_03','MMAPP_item_04','MMAPP_item_05',
  'MMAPP_item_06','MMAPP_item_07','MMAPP_item_08','MMAPP_item_09','MMAPP_item_10',
  'MMAPP_item_11','MMAPP_item_12','MMAPP_item_13','MMAPP_item_14','MMAPP_item_15',
  'MMAPP_item_16','MMAPP_item_17','MMAPP_item_18','MMAPP_item_19','MMAPP_item_20',
  'MMAPP_item_21','MMAPP_item_22','MMAPP_item_23','MMAPP_item_24','MMAPP_item_25',

  // ── SECTION G: MMAPP Functional Impact 26–29 ──────────────
  'MMAPP_item_26','MMAPP_item_27','MMAPP_item_28','MMAPP_item_29',

  // ── SECTION H: MMAPP 30 & 32 ──────────────────────────────
  'MMAPP_item_30',
  'MMAPP_item_32',

  // ── SECTION I: MMAPP Item 31 — Professionals ──────────────
  'MMAPP_item_31_prof',
  'MMAPP_item_31_prof_det',
  'MMAPP_item_31_prof_dct',
  'MMAPP_item_31_prof_dct_det',
  'MMAPP_item_31_prof_nurse',
  'MMAPP_item_31_prof_nurse_det',
  'MMAPP_item_31_prof_lhw',
  'MMAPP_item_31_prof_lhw_det',
  'MMAPP_item_31_prof_oth_i',
  'MMAPP_item_31_prof_oth_i_det',
  'MMAPP_item_31_prof_oth_ii',
  'MMAPP_item_31_prof_oth_ii_det',

  // ── SECTION J: MMAPP Item 31 — Family & Others ────────────
  'MMAPP_item_31_fam_father',
  'MMAPP_item_31_fam_mother',
  'MMAPP_item_31_fam_adult',
  'MMAPP_item_31_fam_adult_det',
  'MMAPP_item_31_fam_minor',
  'MMAPP_item_31_fam_minor_det',
  'MMAPP_item_31_oth_Teacher',
  'MMAPP_item_31_oth_Tch_det',
  'MMAPP_item_31_oth_Friend',
  'MMAPP_item_31_oth_Frnd_det',
  'MMAPP_item_31_oth_Other',
  'MMAPP_item_31_oth_Other_det',

  // ── SECTION K: RCADS Items 1–25 ───────────────────────────
  'RCADS_item_01','RCADS_item_02','RCADS_item_03','RCADS_item_04','RCADS_item_05',
  'RCADS_item_06','RCADS_item_07','RCADS_item_08','RCADS_item_09','RCADS_item_10',
  'RCADS_item_11','RCADS_item_12','RCADS_item_13','RCADS_item_14','RCADS_item_15',
  'RCADS_item_16','RCADS_item_17','RCADS_item_18','RCADS_item_19','RCADS_item_20',
  'RCADS_item_21','RCADS_item_22','RCADS_item_23','RCADS_item_24','RCADS_item_25',

  // ── SECTION L: Assessor Notes ─────────────────────────────
  'Observations',
  'Assessor_Name',

  // ★ ADD NEW TOOL VARIABLE NAMES HERE when more tools are added
];


// ── doGet — health check / test endpoint ─────────────────────
// Open the Web App URL in a browser to confirm it's deployed correctly.
function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({
      status : 'ok',
      message: 'Data Entry System — Apps Script is live.',
      time   : new Date().toISOString()
    }))
    .setMimeType(ContentService.MimeType.JSON);
}


// ── doPost — main data receiver ──────────────────────────────
function doPost(e) {
  // CORS preflight (browsers sometimes send OPTIONS first)
  if (e.parameter && e.parameter['method'] === 'OPTIONS') {
    return buildResponse({status: 'ok'});
  }

  try {
    const data = JSON.parse(e.postData.contents);

    // ── 1. Get or create the correct stream sheet ─────────────
    const ss        = SpreadsheetApp.getActiveSpreadsheet();
    const sheetName = 'Stream' + data.stream;
    let   sheet     = ss.getSheetByName(sheetName);

    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      writeHeaders(sheet);
    } else if (sheet.getLastRow() === 0) {
      writeHeaders(sheet);
    }

    // ── 2. Duplicate check ────────────────────────────────────
    const existingRow = findDuplicateRow(sheet, data);

    if (existingRow > 0 && !data.overwrite) {
      // Duplicate found but overwrite not requested — inform client
      return buildResponse({
        status   : 'duplicate',
        message  : 'A record with the same identifiers already exists.',
        row      : existingRow
      });
    }

    if (existingRow > 0 && data.overwrite) {
      // Overwrite: delete the existing row first
      sheet.deleteRow(existingRow);
    }

    // ── 3. Write the new row ──────────────────────────────────
    const headers = getHeaders(sheet);
    const row     = headers.map(h => {
      if (h === 'timestamp') return new Date().toISOString();
      return data[h] !== undefined ? data[h] : '';
    });
    sheet.appendRow(row);

    // ── 4. Auto-resize columns for readability ────────────────
    try { sheet.autoResizeColumns(1, headers.length); } catch(e) {}

    return buildResponse({status: 'ok', message: 'Record saved successfully.'});

  } catch (err) {
    Logger.log('ERROR: ' + err.toString());
    return buildResponse({status: 'error', message: err.toString()});
  }
}


// ── HELPERS ──────────────────────────────────────────────────

/**
 * Write the fixed header row using COLUMN_ORDER.
 * Any field in COLUMN_ORDER that isn't submitted just gets an empty cell —
 * the column still exists so SPSS import is always consistent.
 */
function writeHeaders(sheet) {
  sheet.appendRow(COLUMN_ORDER);

  // Style the header row
  const headerRange = sheet.getRange(1, 1, 1, COLUMN_ORDER.length);
  headerRange.setFontWeight('bold');
  headerRange.setBackground('#1a73e8');
  headerRange.setFontColor('#ffffff');
  headerRange.setWrap(false);

  // Freeze the header row
  sheet.setFrozenRows(1);
}

/**
 * Return the header array from row 1.
 */
function getHeaders(sheet) {
  const lastCol = sheet.getLastColumn();
  if (lastCol === 0) return COLUMN_ORDER;
  return sheet.getRange(1, 1, 1, lastCol).getValues()[0];
}

/**
 * Search for an existing row whose DUPLICATE_KEY_FIELDS all match data.
 * Returns the 1-based row number, or 0 if no duplicate found.
 */
function findDuplicateRow(sheet, data) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return 0;          // only header, no data yet

  const headers = getHeaders(sheet);
  const allData = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();

  // Build index map: column name → column index in allData rows
  const idxMap = {};
  headers.forEach((h, i) => { idxMap[h] = i; });

  for (let r = 0; r < allData.length; r++) {
    const isMatch = DUPLICATE_KEY_FIELDS.every(field => {
      const sheetVal = String(allData[r][idxMap[field]] || '').trim().toLowerCase();
      const incomingVal = String(data[field] || '').trim().toLowerCase();
      return sheetVal === incomingVal;
    });
    if (isMatch) return r + 2;  // +2 because data starts at row 2 (row 1 = header)
  }
  return 0;
}

/**
 * Build a JSON response with CORS headers.
 */
function buildResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
